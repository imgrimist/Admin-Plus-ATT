const { Client, GatewayIntentBits, Collection, EmbedBuilder } = require(`discord.js`);
const fs = require('fs');
const { listeners } = require('process');
const { Stream } = require('stream');

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent ] }); 
exports.client = client;


client.commands = new Collection();

require('dotenv').config();
const prefix = '*';

const { attConfig } = require('../my-configs');
const { Client: attClient } = require('att-client');
const { EventEmitter } = require('events');

const attbot = new attClient(attConfig)
const functions = fs.readdirSync("./src/functions").filter(file => file.endsWith(".js"));
const eventFiles = fs.readdirSync("./src/events").filter(file => file.endsWith(".js"));
const commandFolders = fs.readdirSync("./src/commands");

exports.attbot = attbot;

(async () => {
    for (file of functions) {
        require(`./functions/${file}`)(client);
    }
    client.handleEvents(eventFiles, "./src/events");
    client.handleCommands(commandFolders, "./src/commands");
    client.login(process.env.token)
    attbot.start()
})();


client.on('messageCreate', message =>{
    if(!message.content.startsWith(prefix) || message.author.bot) return;
    
    attbot.on('connect', async (connection) => { 
    const args = message.content.slice(prefix.length).split(/ +/);
    const command = args.shift().toLowerCase();
    
    const messageArray = message.content.split(" ");
    const arguement = messageArray.slice(1);
    {
    
        if (command == 'ted'){
            connection.send(`player message * "suck teds balls" 9`)
            message.channel.send("```suck teds balls```")
            
        }
    
  
  
}
});
});



attbot.on('connect', async (connection) => {
  console.log(`connection made to ${connection.server.name}`)

  
  const blackListedPlayers = ['a_e'];
  let pvpLoggedPlayers = [];
  const playersWhoAreKillers = [];
  const playersWhoAreKilled = [];
  const playersInQuests = [];
  const hasBeenAtTower = [];
  const inTowerQuest = [];
  const hasBeenAtSwordShrine = [];
  const inSwordShrineQuest = [];
  const hasBeenAtArcheryShrine = [];
  const inArcheryQuest = [];

  attbot.on('connect', async (connetion) => {

  connection.subscribe(`PlayerKilled`, message => {
    const { killerPlayer, killedPlayer } = message.data;

            connection.send(`player set-home ${killedPlayer.id} -1036.897,258.03598,-654.178`);
            connection.send(`player set-home ${killerPlayer.id} -1036.897,258.03598,-654.178`);
            connection.send(`player teleport ${killerPlayer.id} home`);
            connection.send(`player teleport ${killedPlayer.id} home`);
            connection.send(`player message ${player.id} "Welcome to the PVP Arena! In this Arena you can fight other players and if you're the last one standing, you get random rewards!" 7`);  
            pvpLoggedPlayers.push(`${player.username}`);
            console.log(pvpLoggedPlayers);
  
    });
})
  
connection.subscribe('PlayerMovedChunk', message => {
    const { player, newChunk, oldChunk } = message.data;
        
        // PVP Arena System:
        if (newChunk.startsWith('Chunk 16-34')) {
            connection.send(`player set-home ${player.id} -1036.897,258.03598,-654.178`);
            connection.send(`player teleport ${player.id} home`);
            connection.send(`player message ${player.id} "Welcome to the PVP Arena! In this Arena you can fight other players and if you're the last one standing, you get random rewards!" 7`);  
            pvpLoggedPlayers.push(`${player.username}`);
            console.log(pvpLoggedPlayers);
        }
  
        if (newChunk.startsWith('Chunk 16-22') && oldChunk.startsWith('Chunk 15-22')) {
            connection.send(`player set-home ${player.id} -804.7744,135.171,47.674`);
            connection.send(`player teleport ${player.id} home`);
            connection.send(`player message ${player.id} "Welcome back!" 2`);
            var index = pvpLoggedPlayers.indexOf(`${player.id}`);
            pvpLoggedPlayers.splice(index, 1);
            console.log(pvpLoggedPlayers)
  
        }
    
       // Quest System:
        const words = [
            { word: 'Sword Shrine Quest', odds: 1 },
            { word: 'Tower Quest', odds: 1 },
            { word: 'Archery Shrine Quest', odds: 1 }
        ];
        
        const totalOdds = words.reduce((acc, curr) => acc + curr.odds, 0);
        
        const randomNumber = Math.floor(Math.random() * totalOdds);
        
        let currentOdds = 0;
        let randomWord;
        for (const word of words) {
            currentOdds += word.odds;
            if (randomNumber < currentOdds) {
            randomWord = word.word;
            break;
            }
        }
       // Tower Quest
        if (newChunk.startsWith('Chunk 24-34') && playersInQuests.includes(player.id) && inTowerQuest.includes(player.id)) {
            connection.send(`player message ${player.id} "Go into climbing tower entrance and come back here when completed.\n\nYou will be given 65 gold coins." 8`);
        }
        if (newChunk.startsWith('Chunk 24-34') && randomWord === 'Tower Quest' && !playersInQuests.includes(player.id)) {
            playersInQuests.push(player.id);
            inTowerQuest.push(player.id);
            connection.send(`player message ${player.id} "Go into climbing tower entrance and come back here when completed.\n\nYou will be given 65 gold coins." 8`);
            console.log(`People in Tower Quest: ${inTowerQuest}`);
        }
        if (newChunk.startsWith('Chunk 18-5') && inTowerQuest.includes(player.id)) {
            hasBeenAtTower.push(player.id);
            inTowerQuest.splice(inTowerQuest.indexOf(player.id), 1);
            connection.send(`player message ${player.id} "Your quest has been completed!\nGo to the quest chunk to turn it in!" 7`);
        }
        if (newChunk.startsWith('Chunk 24-34') && hasBeenAtTower.includes(player.id)) {
            connection.send(`trade post ${player.id} GoldCoin 65`);
            connection.send(`player message ${player.id} "Welcome back! I just sent you your reward!\n\nCheck your mailbox." 6`);
            hasBeenAtTower.splice(hasBeenAtTower.indexOf(player.id), 1);
            playersInQuests.splice(playersInQuests.indexOf(player.id), 1);
        }
        // Sword Shrine Quest
        if (newChunk.startsWith('Chunk 24-34') && playersInQuests.includes(player.id) && inSwordShrineQuest.includes(player.id)) {
            connection.send(`player message ${player.id} "Go to the Sword Shrine and come back here when completed.\n\nYou will be given 30 gold coins." 8`);
        }
        if (newChunk.startsWith('Chunk 24-34') && randomWord === 'Sword Shrine Quest' && !playersInQuests.includes(player.id)) {
            playersInQuests.push(player.id);
            inSwordShrineQuest.push(player.id);
            connection.send(`player message ${player.id} "Go to the Sword Shrine and come back here when completed.\n\nYou will be given 30 gold coins." 8`);
            console.log(`People in Sword Shrine Quest: ${inSwordShrineQuest}`);
        }
        if (newChunk.startsWith('Chunk 10-34') && inSwordShrineQuest.includes(player.id)) {
            hasBeenAtSwordShrine.push(player.id);
            inSwordShrineQuest.splice(inSwordShrineQuest.indexOf(player.id), 1);
            connection.send(`player message ${player.id} "Your quest has been completed!\nGo to the quest chunk to turn it in!" 7`);
            console.log(`${player.id} has been at the sword shrine`)
  
        }
        if (newChunk.startsWith('Chunk 24-34') && hasBeenAtSwordShrine.includes(player.id)) {
            connection.send(`trade post ${player.id} GoldCoin 30`);
            connection.send(`player message ${player.id} "Welcome back! I just sent you your reward!\n\nCheck your mailbox." 6`);
            hasBeenAtSwordShrine.splice(hasBeenAtSwordShrine.indexOf(player.id), 1);
            playersInQuests.splice(playersInQuests.indexOf(player.id), 1);
        }
        // Archery Quest
        if (newChunk.startsWith('Chunk 24-34') && playersInQuests.includes(player.id) && inArcheryShrineQuest.includes(player.id)) {
            connection.send(`player message ${player.id} "Go to the Archery Shrine and come back here when completed.\n\nYou will be given 25 gold coins." 8`);
        }
        if (newChunk.startsWith('Chunk 24-34') && randomWord === 'Archery Shrine Quest' && !playersInQuests.includes(player.id)) {
            playersInQuests.push(player.id);
            inArcheryShrineQuest.push(player.id);
            connection.send(`player message ${player.id} "Go to the Archery Shrine and come back here when completed.\n\nYou will be given 25 gold coins." 8`);
            console.log(`People in Archery Shrine Quest: ${inArcheryShrineQuest}`);
        }
        if (newChunk.startsWith('Chunk 18-37') && inArcheryShrineQuest.includes(player.id)) {
            hasBeenAtArcheryShrine.push(player.id);
            inArcheryShrineQuest.splice(inArcheryShrineQuest.indexOf(player.id), 1);
            connection.send(`player message ${player.id} "Your quest has been completed!\nGo to the quest chunk to turn it in!" 7`);
            console.log(`${player.id} has been at the Archery Shrine`)
  
        }
        if (newChunk.startsWith('Chunk 24-34') && hasBeenAtArcheryShrine.includes(player.id)) {
            connection.send(`trade post ${player.id} GoldCoin 30`);
            connection.send(`player message ${player.id} "Welcome back! I just sent you your reward!\n\nCheck your mailbox." 6`);
            hasBeenAtArcheryShrine.splice(hasBeenAtArcheryShrine.indexOf(player.id), 1);
            playersInQuests.splice(playersInQuests.indexOf(player.id), 1);
        }
        
    });
  
  connection.subscribe('PlayerKilled', message => {
      
      // PVP Arena Logic:
      const{ killedPlayer, killerPlayer } = message.data;
      var itemId = "";
      var itemNumMin = 0;
      var itemNumMax = 0;
  
      const words = [
          { word: 'GoldCoin', odds: 115 },
          { word: 'Dynamite', odds: 95 },
          { word: 'FlashlightLantern', odds: 10 },
          { word: 'MRKFuelCore', odds: 15 },
          { word: 'MetalBow', odds: 18 },
          { word: 'HebiosHandleKatana', odds: 1 },
          { word: 'MetalHebiosKatanaBlade', odds: 0.1 }
      ];
      
      const totalOdds = words.reduce((acc, curr) => acc + curr.odds, 0);
      
      const randomNumber = Math.floor(Math.random() * totalOdds);
      
      let currentOdds = 0;
      let randomWord;
      for (const word of words) {
          currentOdds += word.odds;
          if (randomNumber < currentOdds) {
          randomWord = word.word;
          break;
          }
      }

      itemId = randomWord;
      
      if (itemId === 'GoldCoin') {
          itemNumMin = 5;
          itemNumMax = 20;
      }
      if (itemId === 'Dynamite') {
          itemNumMin = 1;
          itemNumMax = 5;
      }
      if (itemId === 'FlashlightLantern') {
          itemNumMin = 1;
          itemNumMax = 2;
      }
      if (itemId === 'MRKFuelCore') {
          itemNumMin = 1;
          itemNumMax = 5;
      }
      if (itemId === 'MetalBow') {
          itemNumMin = 1;
          itemNumMax = 1;
      }
      if (itemId === 'HebiosHandleKatana') {
          itemNumMin = 1;
          itemNumMax = 1;
      }
      
      const randomItemAmount = Math.floor(Math.random() * (itemNumMax - itemNumMin + 1)) + itemNumMin;

      var isLast = false
      connection.send(`player set-home ${killedPlayer.id} -804.7744,135.171,47.674`);
      var indexKilled = pvpLoggedPlayers.indexOf(killedPlayer.username);
      pvpLoggedPlayers.splice(indexKilled, 1); 
      console.log(pvpLoggedPlayers);
      
      connection.send(`player teleport ${killedPlayer} home`);
      console.log(pvpLoggedPlayers.length);
      var isCodeRan = true;
      
      if (pvpLoggedPlayers.length === 1 && isCodeRan === true) {
          isLast = true;
      }

      if (pvpLoggedPlayers.length === 1 && isLast === true) {
          connection.send(`player set-home ${pvpLoggedPlayers} -804.7744,135.171,47.674`);
          connection.send(`player teleport ${pvpLoggedPlayers} home`);
          connection.send(`player message ${pvpLoggedPlayers} "YOU WIN!\n\nCheck your mailbox!" 3`);
          connection.send(`trade post ${pvpLoggedPlayers} ${itemId} ${randomItemAmount}`);
          pvpLoggedPlayers.splice(pvpLoggedPlayers.indexOf(killerPlayer.username), 1); 
          console.log(randomItemAmount + ' ' + itemId);
          isLast = false;
          isCodeRan = false;
          console.log(pvpLoggedPlayers);
      }       
  });

  connection.subscribe(`PlayerJoined`, message => {
  const { user } = message.data;
      
      if (blackListedPlayers.includes(user.username)) {
          connection.send(`player kick ${user.id}`);
      }
      
  });
});

