const mongoose = require('mongoose')
const mongodbURL = process.env.MONGODBURL;
const ActivityType = require('discord.js')



mongoose.set('strictQuery', true);

module.exports = {
  name: "ready",
  rest: false,                  
                          
  once: false,
  /**
   * @param {Client} client
   */
  async execute(client) {

    /* Connect to database */
    
    if (!mongodbURL) return ;

    await mongoose.connect(mongodbURL || '', {
        keepAlive: true,
        useNewUrlParser: true,
        useUnifiedTopology: true
    })
    
  
    if (mongoose.connect) {

        console.log("[MONGODB] The client has connected to the database sucessfully!")

    }
const activities = [
  'on spirit valley',
  'and fighting people',
  

];

  setInterval(() => {
    const status = activities[Math.floor(Math.random() * activities.length)];
    client.user.setActivity(status, { type: ActivityType.WATCHING });
    
  }, 5000)



        console.log(`[READY] to look after all the people`
        );
  },
};