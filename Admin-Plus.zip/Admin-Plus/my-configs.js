module.exports = {
   attConfig: {
     clientId: 'client_74a7c11b-403f-44e3-96d4-2dc8bbcc7ce9',
     clientSecret: 't+Ol5iijZ6pDl68DWXf8J3/Rh6R7mZK5ormv25ZB5Ag6FL5YrGrfxP/KtwzQmB8Wioy/Ok0MI+rx02DQ6T1i2Q==',
     scope: [ 'ws.group', 'ws.group_members', 'ws.group_servers', 'ws.group_bans', 'ws.group_invites', 'group.info', 'group.join', 'group.leave', 'group.view', 'group.members', 'group.invite', 'server.view', 'server.console']
  }
} 

