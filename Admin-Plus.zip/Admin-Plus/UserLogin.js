module.exports = {
   attConfig: {
     username: 'put username here',
     password: 'put password here'
    }
} 

