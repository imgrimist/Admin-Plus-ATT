const { Client: AttClient } = require('att-client');
const { attConfig } = require('./UserLogin');
const { clearInterval } = require('timers');
const bot = new AttClient(attConfig);
const mrMushroomHit = [];
const secondPlayerHit = [];
const funnyModePlayers = [];
var killedSprig = false;
var phantomMode = false;
var killMode = false;
var crazyMode = false;
var offMode = true;
var fallMode = false;
var funnyMode = false;
var username = attConfig.username;

bot.on('connect', async (connection) => {
    connection.subscribe("ObjectKilled", message => {
        const { name, killerPlayer } = message.data;

        if (killerPlayer && name) {
            
            if (killerPlayer.username === username && name.includes('Crystal')) {
                killedSprig = true;
                connection.send(`wacky destroy-free CrystalShardBlue`);
                if (phantomMode && killedSprig) {
                    killMode = true;
                    phantomMode = false;
                    killedSprig = false;
                    connection.send(`player message "${username}" "killMode" 3`);
                }
                if (killMode && killedSprig) {
                    crazyMode = true;
                    killMode = false;
                    killedSprig = false;
                    connection.send(`player message "${username}" "crazyMode" 3`);
                }
                if (crazyMode && killedSprig) {
                    offMode = true;
                    crazyMode = false;
                    killedSprig = false;
                    connection.send(`player message "${username}" "offMode" 3`);
                }
                if(offMode && killedSprig) {
                    fallMode = true;
                    offMode = false;
                    killedSprig = false;
                    connection.send(`player message "${username}" "fallMode" 3`);
                }
                if (fallMode && killedSprig) {
                    funnyMode = true;
                    fallMode = false;
                    killedSprig = false;
                    connection.send(`player message "${username}" "funnyMode" 3`);
                }
                if (funnyMode && killedSprig) {
                    phantomMode = true;
                    funnyMode = false;
                    killedSprig = false;
                    connection.send(`player message "${username}" "phantomMode" 3`);
                }

            } 
        }
    });
    
    connection.subscribe('PlayerStateChanged', message => {
        const { user, state, isEnter } = message.data;

        if (state === 'Combat' && isEnter === true && user.username === username) {
            mrMushroomHit.push('Hit');
        }

        if (mrMushroomHit.includes('Hit') && !user.username.startsWith(username) && state === "Combat" && isEnter === true && phantomMode) {
            mrMushroomHit.splice(mrMushroomHit.indexOf('Hit'), 1);
            secondPlayerHit.push('Hit');
            connection.send(`player message ${user.id} "There will be phantoms in 5 seconds..." 5`);
            setTimeout(function() {
                secondPlayerHit.splice(secondPlayerHit.indexOf('Hit'), 1);
                connection.send(`player set-stat ${user.id} nightmare 1`);
                    setTimeout(function() {
                        connection.send(`player message ${user.id} "You thought it was over?" 5`);
                        connection.send(`player set-stat ${user.id} nightmare 1`);
                    }, 45000);
            }, 5000);
        }

        if (mrMushroomHit.includes('Hit') && !user.username.startsWith(username) && state === "Combat" && isEnter === true && delayKillMode) {
            connection.send(`player message ${user.id} "You're dead" 3`);
            connection.send(`player kill ${user.id}`);
        }

        if (mrMushroomHit.includes('Hit') && !user.username.startsWith(username) && state === "Combat" && isEnter === true && crazyMode) {
            crazyLoop = setInterval(function() {
                connection.send(`player message ${user.id} "Crazy?" 2`);
                setTimeout(function() {
                    connection.send(`player message ${user.id} "I was crazy once." 3`);
                }, 2000);
                setTimeout(function() {
                    connection.send(`player message ${user.id} "They locked me in a room." 3`);
                }, 5000);
                setTimeout(function() {
                    connection.send(`player message ${user.id} "A rubber room." 3`);
                }, 8000);
                setTimeout(function() {
                    connection.send(`player message ${user.id} "A rubber room with rats..." 3`);
                }, 11000);
                setTimeout(function() {
                    connection.send(`player message ${user.id} "And rats make me crazy." 3`);
                }, 14000);
            }, 17000);

            setTimeout(function() {
                clearInterval(crazyLoop);
            }, 600000);
        }

        setTimeout(function () {
            if (mrMushroomHit.includes('Hit')) {
                mrMushroomHit.splice(mrMushroomHit.indexOf('Hit'), 1);
            }

        }, 500);

        if (mrMushroomHit.includes('Hit') && !user.username.startsWith(username) && state === "Combat" && isEnter === true && fallMode) {
            connection.send(`player set-home ${user.id} -694.978,800.000,89.285`);
            connection.send(`player teleport ${user.id} home`);
            connection.send(`player set-home ${user.id} -689.292,129.249008,72.125`);
        }

        if (mrMushroomHit.includes('Hit') && !user.username.startsWith(username) && state === "Combat" && isEnter === true && funnyMode) {
            funnyModePlayers.push(user.id);

            const funnyLoop = setInterval(function() {
                connection.send(`trade post ${user.id} SchmeecheePoisonous`);
                connection.send(`trade post ${user.id} SchmeecheeGlowing`);
                connection.send(`trade post ${user.id} SchmeecheeRed`);
                connection.send(`trade post ${user.id} Spriggull`);
            }, 3000);
            
            const funnyLoop2 = setInterval(function() {
                connection.send(`wacky destroy-free SchmeecheeRed`);
                connection.send(`wacky destroy-free SchmeecheeGlowing`);
                connection.send(`wacky destroy-free SchmeecheePoisonous`);
                connection.send(`wacky destroy-free Spriggull`);
            }, 60000);

            if (funnyModePlayers.includes(user.id)) {
                clearInterval(funnyLoop);
                clearInterval(funnyLoop2);
                connection.send(`player message ${user.id} "funnyMode:\nCanceled" 3`);
            }
        }
    });
});

bot.start();